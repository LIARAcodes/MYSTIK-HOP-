import MystikGame from './MystikGame'

export default function HomePage() {
  return <MystikGame />
}
