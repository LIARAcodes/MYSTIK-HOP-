'use client'

import { useCallback, useEffect, useRef, useState, useTransition } from 'react'
import {
  createRoom,
  joinRoom,
  refreshBoard,
  submitMultiplayerScore,
  type MultiplayerBoard,
} from './actions'

type GameState = 'ready' | 'playing' | 'gameover'
type View = 'game' | 'studio' | 'multiplayer'
type Outfit = 'none' | 'crown' | 'cape' | 'tutu'
type ManeColor = 'rainbow' | 'berry' | 'ocean' | 'sunset'
type EyeColor = 'violet' | 'blue' | 'green' | 'rose'
type UnicornGender = 'girl' | 'boy'

type UnicornLook = {
  name: string
  gender: UnicornGender
  outfit: Outfit
  maneColor: ManeColor
  eyeColor: EyeColor
}

type Pipe = {
  id: number
  x: number
  gapY: number
  counted: boolean
}

const BIRD_X = 28
const BIRD_SIZE = 7
const PIPE_WIDTH = 13
const PIPE_GAP = 25
const GRAVITY = 42
const FLAP_FORCE = -15.5
const PIPE_SPEED = 24

const maneStyles: Record<ManeColor, string> = {
  rainbow: 'linear-gradient(#ff7fbd,#a983ff,#65d9ee)',
  berry: 'linear-gradient(#ff4b9b,#b64dea,#7138a8)',
  ocean: 'linear-gradient(#42d9db,#3f9ee8,#675ee9)',
  sunset: 'linear-gradient(#ff8a65,#ffca5c,#f062b0)',
}

const eyeStyles: Record<EyeColor, string> = {
  violet: '#573a70',
  blue: '#287dc2',
  green: '#2d9a78',
  rose: '#d94f89',
}

const outfitLabels: { value: Outfit; label: string }[] = [
  { value: 'none', label: 'Natural' },
  { value: 'crown', label: 'Star crown' },
  { value: 'cape', label: 'Hero cape' },
  { value: 'tutu', label: 'Cloud tutu' },
]

const maneLabels: { value: ManeColor; label: string; color: string }[] = [
  { value: 'rainbow', label: 'Rainbow', color: '#a983ff' },
  { value: 'berry', label: 'Berry', color: '#d94f9c' },
  { value: 'ocean', label: 'Ocean', color: '#42b8df' },
  { value: 'sunset', label: 'Sunset', color: '#ff9563' },
]

const eyeLabels: { value: EyeColor; label: string; color: string }[] = [
  { value: 'violet', label: 'Violet', color: '#573a70' },
  { value: 'blue', label: 'Sky', color: '#287dc2' },
  { value: 'green', label: 'Mint', color: '#2d9a78' },
  { value: 'rose', label: 'Rose', color: '#d94f89' },
]

const genderLabels: { value: UnicornGender; label: string; pronoun: string }[] = [
  { value: 'girl', label: 'Girl', pronoun: 'Her' },
  { value: 'boy', label: 'Boy', pronoun: 'His' },
]

function Cloud({ className }: { className: string }) {
  return (
    <div className={`absolute ${className}`}>
      <span className="absolute bottom-0 left-1/2 h-[55%] w-full -translate-x-1/2 rounded-full bg-white/80" />
      <span className="absolute bottom-[15%] left-[12%] h-[70%] w-[45%] rounded-full bg-white/80" />
      <span className="absolute bottom-[10%] right-[10%] h-full w-[52%] rounded-full bg-white/80" />
    </div>
  )
}

function Unicorn({
  y,
  rotation,
  isPlaying,
  look,
  x = BIRD_X,
  size = BIRD_SIZE,
}: {
  y: number
  rotation: number
  isPlaying: boolean
  look: UnicornLook
  x?: number
  size?: number
}) {
  return (
    <div
      className="absolute z-30"
      style={{
        left: `${x}%`,
        top: `${y}%`,
        width: `${size}%`,
        aspectRatio: '1.45 / 1',
        transform: `translate(-50%, -50%) rotate(${rotation}deg)`,
        transition: isPlaying ? 'none' : 'top 300ms ease',
      }}
    >
      <div className="absolute bottom-[12%] left-[14%] h-[58%] w-[70%] rounded-[48%_54%_47%_50%] border-2 border-[#704a91] bg-[#fff9ff] shadow-[inset_-5px_-5px_0_#e9d8f5,0_3px_0_rgba(80,42,100,.2)]">
        <div className="absolute -right-[20%] -top-[31%] h-[83%] w-[50%] rotate-[-8deg] rounded-[48%_55%_50%_44%] border-2 border-[#704a91] bg-[#fff9ff]">
          <div
            className="absolute -right-[5%] top-[28%] h-[27%] w-[22%] rounded-full"
            style={{ backgroundColor: eyeStyles[look.eyeColor] }}
          >
            <div className="absolute right-[12%] top-[10%] h-[30%] w-[30%] rounded-full bg-white" />
          </div>
          <div className="absolute -top-[31%] left-[26%] h-[45%] w-[16%] -rotate-6 bg-[linear-gradient(135deg,#fff18a,#ff91d1,#9a8cff)] [clip-path:polygon(50%_0,100%_100%,0_100%)]" />
          <div className="absolute -top-[18%] right-[8%] h-[30%] w-[28%] rotate-[22deg] rounded-[80%_10%_80%_10%] border-2 border-[#704a91] bg-[#f3d8f8]" />
          <div
            className="unicorn-mane absolute -left-[15%] top-[-6%] h-[105%] w-[35%] rounded-[80%_20%_75%_30%] shadow-[inset_-3px_0_0_rgba(101,62,137,.2)]"
            style={{ background: maneStyles[look.maneColor] }}
          />
          {look.outfit === 'crown' && (
            <div className="absolute -top-[45%] right-[4%] h-[30%] w-[58%] border-2 border-[#6a447f] bg-[#ffe56f] [clip-path:polygon(0_100%,0_32%,24%_68%,43%_0,63%_68%,100%_25%,100%_100%)]" />
          )}
        </div>
        <div className="unicorn-wing absolute left-[18%] top-[-25%] h-[65%] w-[55%] origin-bottom-right -rotate-12 rounded-[80%_15%_75%_20%] border-2 border-[#704a91] bg-[linear-gradient(135deg,#fff,#e1c8ff)] shadow-[inset_0_-5px_0_#d0b3ef]" />
        <div
          className="unicorn-tail absolute -left-[43%] top-[2%] h-[65%] w-[58%] rotate-12 rounded-[75%_20%_75%_25%]"
          style={{ background: maneStyles[look.maneColor] }}
        />
        {look.outfit === 'cape' && (
          <div className="absolute -bottom-[28%] left-[18%] h-[80%] w-[76%] rotate-6 rounded-[20%_30%_65%_25%] border-2 border-[#704a91] bg-[linear-gradient(135deg,#ff4f9d,#9b65e8)] shadow-[inset_0_-5px_0_rgba(83,45,119,.22)]" />
        )}
        {look.outfit === 'tutu' && (
          <div className="absolute -bottom-[8%] left-[5%] h-[34%] w-[92%] rounded-[20%_20%_70%_70%] border-2 border-[#704a91] bg-[repeating-linear-gradient(100deg,#ffd6f0_0,#ffd6f0_14%,#e6c7ff_14%,#e6c7ff_28%)]" />
        )}
        <div className="absolute bottom-[-28%] left-[18%] h-[43%] w-[12%] rotate-12 rounded-full border-2 border-[#704a91] bg-[#fff9ff]" />
        <div className="absolute bottom-[-28%] right-[18%] h-[43%] w-[12%] -rotate-12 rounded-full border-2 border-[#704a91] bg-[#fff9ff]" />
        <div className="absolute left-[51%] top-[58%] h-[16%] w-[16%] rotate-12 bg-[#ff8bc8] [clip-path:polygon(50%_0,61%_35%,98%_35%,68%_56%,79%_94%,50%_72%,21%_94%,32%_56%,2%_35%,39%_35%)]" />
      </div>
    </div>
  )
}

function CrystalPillar({ id, orientation }: { id: number; orientation: 'top' | 'bottom' }) {
  const gradientId = `crystal-${orientation}-${id}`
  const isTop = orientation === 'top'
  const outline = isTop
    ? '10,0 90,0 96,78 72,90 50,100 28,90 4,78'
    : '50,0 72,10 96,22 90,100 10,100 4,22 28,10'

  return (
    <svg
      aria-hidden="true"
      className="crystal-svg h-full w-full"
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
    >
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#7044aa" />
          <stop offset=".4" stopColor="#c18bec" />
          <stop offset=".58" stopColor="#efd0ff" />
          <stop offset="1" stopColor="#7650b7" />
        </linearGradient>
      </defs>
      <polygon
        points={outline}
        fill={`url(#${gradientId})`}
        stroke="#54326f"
        strokeWidth="3"
        strokeLinejoin="round"
        vectorEffect="non-scaling-stroke"
      />
      {isTop ? (
        <>
          <polygon points="10,0 43,0 50,100 28,90 4,78" fill="#6d47a4" opacity=".48" />
          <polygon points="43,0 68,0 50,100" fill="#e8bdff" opacity=".42" />
          <polygon points="68,0 90,0 96,78 72,90 50,100" fill="#8756c0" opacity=".35" />
          <path
            d="M49 8 51 76"
            stroke="white"
            strokeWidth="5"
            strokeLinecap="round"
            vectorEffect="non-scaling-stroke"
            opacity=".48"
          />
        </>
      ) : (
        <>
          <polygon points="50,0 28,10 4,22 10,100 42,100" fill="#6d47a4" opacity=".48" />
          <polygon points="50,0 68,10 61,100 40,100" fill="#e8bdff" opacity=".42" />
          <polygon points="72,10 96,22 90,100 61,100 50,0" fill="#8756c0" opacity=".35" />
          <path
            d="M51 25 49 88"
            stroke="white"
            strokeWidth="5"
            strokeLinecap="round"
            vectorEffect="non-scaling-stroke"
            opacity=".48"
          />
        </>
      )}
    </svg>
  )
}

function PipePair({ pipe }: { pipe: Pipe }) {
  const topHeight = pipe.gapY - PIPE_GAP / 2
  const bottomTop = pipe.gapY + PIPE_GAP / 2

  return (
    <>
      <div
        className="absolute top-0 z-20"
        style={{ left: `${pipe.x}%`, width: `${PIPE_WIDTH}%`, height: `${topHeight}%` }}
      >
        <CrystalPillar id={pipe.id} orientation="top" />
      </div>
      <div
        className="absolute bottom-0 z-20"
        style={{ left: `${pipe.x}%`, width: `${PIPE_WIDTH}%`, top: `${bottomTop}%` }}
      >
        <CrystalPillar id={pipe.id} orientation="bottom" />
      </div>
    </>
  )
}

function App() {
  const [activeView, setActiveView] = useState<View>('game')
  const [gameState, setGameState] = useState<GameState>('ready')
  const [birdY, setBirdY] = useState(45)
  const [birdVelocity, setBirdVelocity] = useState(0)
  const [pipes, setPipes] = useState<Pipe[]>([])
  const [score, setScore] = useState(0)
  const [bestScore, setBestScore] = useState(0)
  const [musicOn, setMusicOn] = useState(true)
  const [sfxOn, setSfxOn] = useState(true)
  const [musicPlaying, setMusicPlaying] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [look, setLook] = useState<UnicornLook>({
    name: 'Luna',
    gender: 'girl',
    outfit: 'none',
    maneColor: 'rainbow',
    eyeColor: 'violet',
  })
  const [playerName, setPlayerName] = useState('')
  const [roomName, setRoomName] = useState('')
  const [roomCode, setRoomCode] = useState('')
  const [board, setBoard] = useState<MultiplayerBoard | null>(null)
  const [multiplayerError, setMultiplayerError] = useState('')
  const [scorePosted, setScorePosted] = useState(false)
  const [isMultiplayerPending, startMultiplayerTransition] = useTransition()

  const gameStateRef = useRef(gameState)
  const birdYRef = useRef(birdY)
  const birdVelocityRef = useRef(birdVelocity)
  const pipesRef = useRef(pipes)
  const scoreRef = useRef(score)
  const nextPipeId = useRef(1)
  const lastTimeRef = useRef<number | null>(null)
  const audioRef = useRef<AudioContext | null>(null)
  const musicRef = useRef<HTMLAudioElement | null>(null)
  const musicStartedRef = useRef(false)
  const settingsRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    setBestScore(Number(localStorage.getItem('star-hop-best') || 0))
    const savedLook = localStorage.getItem('mystik-unicorn-look')
    if (savedLook) {
      try {
        const parsed = JSON.parse(savedLook) as Partial<UnicornLook>
        if (
          outfitLabels.some((item) => item.value === parsed.outfit) &&
          maneLabels.some((item) => item.value === parsed.maneColor) &&
          eyeLabels.some((item) => item.value === parsed.eyeColor)
        ) {
          setLook({
            name: typeof parsed.name === 'string' && parsed.name.trim() ? parsed.name : 'Luna',
            gender: genderLabels.some((item) => item.value === parsed.gender)
              ? (parsed.gender as UnicornGender)
              : 'girl',
            outfit: parsed.outfit as Outfit,
            maneColor: parsed.maneColor as ManeColor,
            eyeColor: parsed.eyeColor as EyeColor,
          })
        }
      } catch {
        // Keep the default look when saved browser data is invalid.
      }
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('mystik-unicorn-look', JSON.stringify(look))
  }, [look])

  useEffect(() => {
    gameStateRef.current = gameState
  }, [gameState])

  useEffect(() => {
    const music = musicRef.current
    if (!music) return

    music.volume = 0.36
    if (!musicOn) {
      music.pause()
    } else if (musicStartedRef.current) {
      void music.play().catch(() => {
        musicStartedRef.current = false
        setMusicPlaying(false)
      })
    }
  }, [musicOn])

  useEffect(() => {
    if (!settingsOpen) return

    const closeOnOutsidePress = (event: PointerEvent) => {
      if (!settingsRef.current?.contains(event.target as Node)) setSettingsOpen(false)
    }
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSettingsOpen(false)
    }

    document.addEventListener('pointerdown', closeOnOutsidePress)
    document.addEventListener('keydown', closeOnEscape)
    return () => {
      document.removeEventListener('pointerdown', closeOnOutsidePress)
      document.removeEventListener('keydown', closeOnEscape)
    }
  }, [settingsOpen])

  useEffect(() => {
    if (activeView !== 'multiplayer' || !board) return
    const interval = window.setInterval(() => {
      startMultiplayerTransition(async () => {
        const result = await refreshBoard(board.roomId)
        if (result.ok) setBoard(result.board)
      })
    }, 5000)
    return () => window.clearInterval(interval)
  }, [activeView, board?.roomId])

  const beep = useCallback(
    (frequency: number, duration = 0.06) => {
      if (!sfxOn) return
      try {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext
        audioRef.current ||= new AudioContextClass()
        const context = audioRef.current
        const oscillator = context.createOscillator()
        const gain = context.createGain()
        oscillator.frequency.value = frequency
        oscillator.type = 'sine'
        gain.gain.setValueAtTime(0.08, context.currentTime)
        gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + duration)
        oscillator.connect(gain)
        gain.connect(context.destination)
        oscillator.start()
        oscillator.stop(context.currentTime + duration)
      } catch {
        // Audio is an optional enhancement and can be blocked by the browser.
      }
    },
    [sfxOn],
  )

  const createPipes = useCallback(
    (): Pipe[] => [
      { id: nextPipeId.current++, x: 112, gapY: 39 + Math.random() * 24, counted: false },
      { id: nextPipeId.current++, x: 164, gapY: 39 + Math.random() * 24, counted: false },
      { id: nextPipeId.current++, x: 216, gapY: 39 + Math.random() * 24, counted: false },
    ],
    [],
  )

  const startMusic = useCallback(
    async (force = false) => {
      const music = musicRef.current
      if ((!musicOn && !force) || !music) return false
      if (!music.paused) {
        musicStartedRef.current = true
        setMusicPlaying(true)
        return true
      }

      music.volume = 0.36
      try {
        await music.play()
        musicStartedRef.current = true
        setMusicPlaying(true)
        return true
      } catch {
        musicStartedRef.current = false
        setMusicPlaying(false)
        return false
      }
    },
    [musicOn],
  )

  const handleMusicToggle = () => {
    if (musicOn && musicPlaying) {
      setMusicOn(false)
      return
    }

    setMusicOn(true)
    void startMusic(true)
  }

  useEffect(() => {
    if (!musicOn || musicStartedRef.current) return

    const removeUnlockListeners = () => {
      window.removeEventListener('pointerdown', unlockMusic, true)
      window.removeEventListener('keydown', unlockMusic, true)
    }
    const unlockMusic = () => {
      void startMusic().then((started) => {
        if (started) removeUnlockListeners()
      })
    }

    window.addEventListener('pointerdown', unlockMusic, true)
    window.addEventListener('keydown', unlockMusic, true)
    return removeUnlockListeners
  }, [musicOn, startMusic])

  const startGame = useCallback(() => {
    const freshPipes = createPipes()
    birdYRef.current = 45
    birdVelocityRef.current = FLAP_FORCE
    pipesRef.current = freshPipes
    scoreRef.current = 0
    lastTimeRef.current = null
    setBirdY(45)
    setBirdVelocity(FLAP_FORCE)
    setPipes(freshPipes)
    setScore(0)
    setScorePosted(false)
    setActiveView('game')
    setGameState('playing')
    void startMusic()
    beep(560)
  }, [beep, createPipes, startMusic])

  const flap = useCallback(() => {
    if (gameStateRef.current === 'ready' || gameStateRef.current === 'gameover') {
      startGame()
      return
    }
    birdVelocityRef.current = FLAP_FORCE
    setBirdVelocity(FLAP_FORCE)
    beep(660)
  }, [beep, startGame])

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (activeView === 'game' && (event.code === 'Space' || event.code === 'ArrowUp')) {
        event.preventDefault()
        flap()
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [activeView, flap])

  const changeView = (view: View) => {
    setActiveView(view)
    if (gameStateRef.current === 'playing') {
      setGameState('ready')
      setBirdY(45)
      setPipes([])
      setScore(0)
    }
  }

  const handleCreateRoom = () => {
    setMultiplayerError('')
    startMultiplayerTransition(async () => {
      const result = await createRoom({ roomName, playerName })
      if (result.ok) {
        setBoard(result.board)
        setRoomCode(result.board.roomCode)
      } else {
        setMultiplayerError(result.error)
      }
    })
  }

  const handleJoinRoom = () => {
    if (playerName.trim().length < 2) {
      setMultiplayerError('Add your player name before joining.')
      return
    }
    setMultiplayerError('')
    startMultiplayerTransition(async () => {
      const result = await joinRoom({ code: roomCode })
      if (result.ok) {
        setBoard(result.board)
        setRoomCode(result.board.roomCode)
      } else {
        setMultiplayerError(result.error)
      }
    })
  }

  const postScore = () => {
    if (!board || scorePosted) return
    setMultiplayerError('')
    startMultiplayerTransition(async () => {
      const result = await submitMultiplayerScore({
        roomId: board.roomId,
        playerName,
        score,
        outfit: look.outfit,
        maneColor: look.maneColor,
        eyeColor: look.eyeColor,
      })
      if (result.ok) {
        setBoard(result.board)
        setScorePosted(true)
      } else {
        setMultiplayerError(result.error)
      }
    })
  }

  useEffect(() => {
    let animationFrame = 0

    const gameLoop = (time: number) => {
      if (gameStateRef.current !== 'playing') {
        lastTimeRef.current = null
        animationFrame = requestAnimationFrame(gameLoop)
        return
      }

      const delta = Math.min((time - (lastTimeRef.current ?? time)) / 1000, 0.033)
      lastTimeRef.current = time

      const nextVelocity = birdVelocityRef.current + GRAVITY * delta
      const nextY = birdYRef.current + nextVelocity * delta
      let scored = false

      const nextPipes = pipesRef.current.map((pipe) => {
        const moved = { ...pipe, x: pipe.x - PIPE_SPEED * delta }
        if (!moved.counted && moved.x + PIPE_WIDTH < BIRD_X) {
          moved.counted = true
          scored = true
        }
        return moved
      })

      const rightmost = Math.max(...nextPipes.map((pipe) => pipe.x))
      nextPipes.forEach((pipe) => {
        if (pipe.x + PIPE_WIDTH < -3) {
          pipe.x = rightmost + 52
          pipe.gapY = 38 + Math.random() * 25
          pipe.counted = false
        }
      })

      const birdLeft = BIRD_X - BIRD_SIZE * 0.36
      const birdRight = BIRD_X + BIRD_SIZE * 0.36
      const birdTop = nextY - BIRD_SIZE * 0.32
      const birdBottom = nextY + BIRD_SIZE * 0.32
      const hitPipe = nextPipes.some((pipe) => {
        const overlapsX = birdRight > pipe.x && birdLeft < pipe.x + PIPE_WIDTH
        return (
          overlapsX && (birdTop < pipe.gapY - PIPE_GAP / 2 || birdBottom > pipe.gapY + PIPE_GAP / 2)
        )
      })

      if (nextY > 91 || nextY < 1 || hitPipe) {
        const finalScore = scoreRef.current
        const nextBest = Math.max(bestScore, finalScore)
        setBestScore(nextBest)
        localStorage.setItem('star-hop-best', String(nextBest))
        setGameState('gameover')
        beep(150, 0.18)
      } else {
        if (scored) {
          scoreRef.current += 1
          setScore(scoreRef.current)
          beep(880, 0.1)
        }
        birdYRef.current = nextY
        birdVelocityRef.current = nextVelocity
        pipesRef.current = nextPipes
        setBirdY(nextY)
        setBirdVelocity(nextVelocity)
        setPipes(nextPipes)
      }

      animationFrame = requestAnimationFrame(gameLoop)
    }

    animationFrame = requestAnimationFrame(gameLoop)
    return () => cancelAnimationFrame(animationFrame)
  }, [beep, bestScore])

  const displayName = look.name.trim() || 'Luna'

  return (
    <main className="flex min-h-screen flex-col bg-[#e7d6ff] text-[#4f376b]">
      <audio
        ref={musicRef}
        src="/audio/on-and-on-instrumental-loop.mp3"
        loop
        preload="auto"
        playsInline
        onPlay={() => setMusicPlaying(true)}
        onPause={() => setMusicPlaying(false)}
        aria-hidden="true"
      />
      <header className="z-50 flex h-[68px] shrink-0 items-center justify-between border-b-[3px] border-[#5c3f7b] bg-[#fff5fc] px-3 sm:px-8">
        <button
          className="font-game -rotate-1 text-[25px] tracking-tight text-[#583b75] sm:text-[30px]"
          onClick={() => {
            setActiveView('game')
            setGameState('ready')
            setBirdY(45)
            setPipes([])
            setScore(0)
          }}
        >
          MYSTIK HOP<span className="text-[#f36daf]">!</span>
        </button>
        <nav className="absolute bottom-[-51px] left-1/2 z-[60] flex -translate-x-1/2 gap-1 rounded-b-2xl border-x-[3px] border-b-[3px] border-[#5c3f7b] bg-[#fff5fc] p-1.5 shadow-[0_4px_0_rgba(92,63,123,.16)] sm:static sm:translate-x-0 sm:rounded-full sm:border-[2px] sm:p-1">
          {(
            [
              ['game', 'Play'],
              ['studio', 'Dress up'],
              ['multiplayer', 'Multiplayer'],
            ] as const
          ).map(([view, label]) => (
            <button
              key={view}
              onClick={() => changeView(view)}
              className={`whitespace-nowrap rounded-full px-3 py-2 text-[10px] font-black uppercase tracking-wide transition-colors sm:px-4 sm:text-xs ${
                activeView === view
                  ? 'bg-[#5c3f7b] text-white'
                  : 'text-[#5c3f7b] hover:bg-[#f1dff3]'
              }`}
            >
              {label}
            </button>
          ))}
        </nav>
        <div ref={settingsRef} className="relative flex items-center gap-2 sm:gap-3">
          <div className="hidden rounded-full border-2 border-[#5c3f7b] bg-white px-4 py-2 text-xs font-black uppercase tracking-wider shadow-[2px_2px_0_#5c3f7b] xl:block">
            Best {bestScore}
          </div>
          <a
            href="https://linktr.ee/liaarrraaaa"
            target="_blank"
            rel="noopener noreferrer"
            className="flex h-10 items-center gap-2 rounded-full border-2 border-[#5c3f7b] bg-[#7fe1d8] px-2.5 text-xs font-black uppercase shadow-[2px_2px_0_#5c3f7b] transition-colors hover:bg-[#5bd6cc] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#5c3f7b] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none lg:px-3"
            aria-label="Open Linktree in a new tab"
          >
            <svg
              width="17"
              height="17"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M14 5h5v5" />
              <path d="m19 5-8 8" />
              <path d="M19 13v5a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5" />
            </svg>
            <span>Linktree</span>
          </a>
          <button
            onClick={() => setSettingsOpen((current) => !current)}
            className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-[#5c3f7b] bg-[#fff3a0] text-[#5c3f7b] shadow-[2px_2px_0_#5c3f7b] transition-colors hover:bg-[#ffe985] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none"
            aria-label="Open audio settings"
            aria-expanded={settingsOpen}
            aria-controls="audio-settings"
          >
            <svg
              width="19"
              height="19"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.25"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21h-4v-.1A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H3v-4h.1A1.7 1.7 0 0 0 4.6 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V3h4v.1A1.7 1.7 0 0 0 15.4 4.6a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 9c.13.4.37.75.7 1 .31.24.7.38 1.1.4h.1v4h-.1a1.7 1.7 0 0 0-1.8.6Z" />
            </svg>
          </button>

          {settingsOpen && (
            <div
              id="audio-settings"
              role="dialog"
              aria-label="Audio settings"
              className="absolute right-0 top-12 z-[80] w-[min(280px,calc(100vw-2rem))] rounded-[22px] border-[3px] border-[#5c3f7b] bg-[#fff5fc] p-4 shadow-[6px_7px_0_#5c3f7b]"
            >
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <p className="font-game text-lg leading-none text-[#5c3f7b]">Audio settings</p>
                  <p className="mt-1 text-[9px] font-black uppercase tracking-[.14em] text-[#8a719d]">
                    Mix your magic
                  </p>
                </div>
                <button
                  onClick={() => setSettingsOpen(false)}
                  className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-[#5c3f7b] bg-white"
                  aria-label="Close audio settings"
                >
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeLinecap="round"
                    aria-hidden="true"
                  >
                    <path d="m6 6 12 12M18 6 6 18" />
                  </svg>
                </button>
              </div>

              <div className="space-y-2">
                <button
                  role="switch"
                  aria-checked={musicOn}
                  onClick={handleMusicToggle}
                  className="flex w-full items-center justify-between rounded-2xl border-2 border-[#5c3f7b]/25 bg-[#ffe0f0] px-3 py-3 text-left transition-colors hover:border-[#5c3f7b]/50"
                >
                  <span>
                    <span className="block text-[11px] font-black uppercase tracking-wide">
                      Background music
                    </span>
                    <span className="mt-0.5 block text-[9px] font-bold uppercase tracking-wide text-[#80668e]">
                      {musicOn ? (musicPlaying ? 'Playing softly' : 'Tap to start') : 'Muted'}
                    </span>
                  </span>
                  <span
                    className={`relative h-7 w-12 rounded-full border-2 border-[#5c3f7b] transition-colors ${
                      musicOn ? 'bg-[#16c9c8]' : 'bg-[#d7c9df]'
                    }`}
                    aria-hidden="true"
                  >
                    <span
                      className={`absolute top-0.5 h-5 w-5 rounded-full border-2 border-[#5c3f7b] bg-white transition-transform ${
                        musicOn ? 'translate-x-[21px]' : 'translate-x-0.5'
                      }`}
                    />
                  </span>
                </button>

                <button
                  role="switch"
                  aria-checked={sfxOn}
                  onClick={() => setSfxOn((current) => !current)}
                  className="flex w-full items-center justify-between rounded-2xl border-2 border-[#5c3f7b]/25 bg-[#e5ddff] px-3 py-3 text-left transition-colors hover:border-[#5c3f7b]/50"
                >
                  <span>
                    <span className="block text-[11px] font-black uppercase tracking-wide">
                      Sound effects
                    </span>
                    <span className="mt-0.5 block text-[9px] font-bold uppercase tracking-wide text-[#80668e]">
                      {sfxOn ? 'Flaps, scores & crashes' : 'Muted'}
                    </span>
                  </span>
                  <span
                    className={`relative h-7 w-12 rounded-full border-2 border-[#5c3f7b] transition-colors ${
                      sfxOn ? 'bg-[#f36daf]' : 'bg-[#d7c9df]'
                    }`}
                    aria-hidden="true"
                  >
                    <span
                      className={`absolute top-0.5 h-5 w-5 rounded-full border-2 border-[#5c3f7b] bg-white transition-transform ${
                        sfxOn ? 'translate-x-[21px]' : 'translate-x-0.5'
                      }`}
                    />
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      <section
        className="game-stage relative min-h-0 flex-1 cursor-pointer select-none overflow-hidden"
        onPointerDown={(event) => {
          if (activeView !== 'game') return
          if ((event.target as HTMLElement).closest('button, a')) return
          flap()
        }}
        aria-label="Unicorn game area. Tap or press space to fly."
      >
        <div className="absolute inset-0 bg-[linear-gradient(#aaa2f3_0%,#e7c8f5_48%,#ffd9ea_100%)]" />
        <div className="sun absolute right-[10%] top-[10%] h-24 w-24 rounded-full border-[3px] border-[#e8acdd] bg-[#fff7db] shadow-[0_0_0_12px_rgba(255,237,249,.3)] sm:h-32 sm:w-32" />
        <div className="rainbow absolute -right-[8%] top-[21%] h-[42%] w-[58%] rounded-t-full border-[13px] border-b-0 border-[#f39acb]/40 shadow-[inset_0_13px_0_rgba(255,219,122,.38),inset_0_26px_0_rgba(127,222,210,.32),inset_0_39px_0_rgba(154,137,239,.34)]" />
        <span className="sparkle absolute left-[13%] top-[12%] text-2xl text-white">✦</span>
        <span className="sparkle-delayed absolute left-[57%] top-[19%] text-lg text-[#fff6b7]">
          ✦
        </span>
        <span className="sparkle absolute right-[18%] top-[49%] text-xl text-white">✦</span>
        <Cloud className="cloud-one left-[7%] top-[17%] h-14 w-32" />
        <Cloud className="cloud-two right-[20%] top-[31%] h-10 w-24 opacity-75" />
        <Cloud className="cloud-three left-[48%] top-[8%] h-8 w-20 opacity-60" />

        <div className="city absolute bottom-[9%] left-0 right-0 h-[25%] opacity-40">
          <div className="absolute bottom-0 left-[-3%] h-[72%] w-[18%] rounded-t-[50%] bg-[#b18bd1]" />
          <div className="absolute bottom-0 left-[12%] h-[95%] w-[25%] rounded-t-[55%] bg-[#d195c5]" />
          <div className="absolute bottom-0 left-[31%] h-[62%] w-[22%] rounded-t-[50%] bg-[#9c89d1]" />
          <div className="absolute bottom-0 left-[48%] h-[110%] w-[28%] rounded-t-[50%] bg-[#c18fca]" />
          <div className="absolute bottom-0 right-[3%] h-[78%] w-[27%] rounded-t-[55%] bg-[#9a86ca]" />
        </div>

        <a
          href="https://youtu.be/plnWPAYYjSw"
          target="_blank"
          rel="noopener noreferrer"
          className="absolute bottom-[11.5%] right-3 z-50 flex max-w-[calc(100%-1.5rem)] items-center gap-1.5 rounded-full border-2 border-[#5c3f7b] bg-[#fff5fc]/90 px-3 py-1.5 text-[9px] font-black uppercase tracking-wide text-[#5c3f7b] shadow-[2px_2px_0_#5c3f7b] backdrop-blur-sm transition-colors hover:bg-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#5c3f7b] sm:right-5 sm:text-[10px]"
          aria-label="Music credit: On and On instrumental by Cartoon and Jéja featuring Daniel Levi. Open the release in a new tab."
        >
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <path d="M9 18V5l10-2v13" />
            <circle cx="6" cy="18" r="3" />
            <circle cx="16" cy="16" r="3" />
          </svg>
          <span>On &amp; On · Cartoon &amp; Jéja ft. Daniel Levi</span>
        </a>

        {activeView === 'game' && (
          <>
            {pipes.map((pipe) => (
              <PipePair key={pipe.id} pipe={pipe} />
            ))}
            <Unicorn
              y={birdY}
              rotation={Math.max(-25, Math.min(68, birdVelocity * 3.2))}
              isPlaying={gameState === 'playing'}
              look={look}
            />
          </>
        )}

        <div className="absolute bottom-0 left-0 right-0 z-40 h-[10%] min-h-12 border-t-[4px] border-[#67447f] bg-[#e397ce]">
          <div className="h-[13px] w-full border-b-[3px] border-[#67447f] bg-[repeating-linear-gradient(135deg,#ffe687_0,#ffe687_9px,#f8a5d0_9px,#f8a5d0_18px,#a78aec_18px,#a78aec_27px)]" />
          <div className="h-full bg-[#d8b3e8] bg-[radial-gradient(#b383cf_1.5px,transparent_1.5px)] [background-size:16px_16px]" />
        </div>

        {activeView === 'game' && gameState === 'playing' && (
          <div className="pointer-events-none absolute left-1/2 top-[8%] z-40 -translate-x-1/2">
            <div className="font-game text-[64px] text-white drop-shadow-[0_4px_0_#173e48] sm:text-[76px]">
              {score}
            </div>
          </div>
        )}

        {activeView === 'game' && gameState === 'ready' && (
          <div className="absolute inset-0 z-40 flex items-center justify-center px-4 pb-[7%] pt-3 sm:px-6">
            <div className="flex w-full max-w-[610px] flex-col items-center text-center">
              <div className="mb-3 inline-block -rotate-2 rounded-full border-[3px] border-[#5c3f7b] bg-[#16c9c8] px-6 py-2 text-[11px] font-black uppercase tracking-[.16em] text-white shadow-[5px_5px_0_#5c3f7b] sm:px-8 sm:text-sm">
                Dream big with magic hooves!
              </div>
              <h1 className="font-game flex flex-col items-center leading-[.82] tracking-[.015em]">
                <span className="mystik-title-white text-[clamp(56px,10vh,90px)]">R U</span>
                <span className="mystik-title-yellow mt-2 text-[clamp(58px,11vh,96px)]">READY</span>
                <span className="mystik-title-yellow mt-2 text-[clamp(54px,10vh,88px)]">TO</span>
                <span className="mystik-title-pink mt-2 text-[clamp(48px,9.4vh,82px)]">
                  SPARKLE?!
                </span>
              </h1>
              <button
                onClick={startGame}
                className="mystik-start-button font-game mt-7 w-full max-w-[560px] rounded-[22px] border-[3px] border-[#5c3f7b] bg-[linear-gradient(110deg,#ffe989,#ffacd5)] px-5 py-4 text-[clamp(16px,2.8vh,24px)] leading-[1.35] tracking-[.04em] text-[#5c3f7b] shadow-[7px_8px_0_#5c3f7b] transition-transform hover:-translate-y-1 active:translate-x-1 active:translate-y-1 active:shadow-none sm:py-5"
              >
                TAP TO SPARKLE AND THEN
                <br />
                <span className="inline-flex items-center justify-center gap-2">
                  HIT
                  <kbd className="inline-flex h-8 min-w-20 items-center justify-center rounded-lg border-[2px] border-[#5c3f7b] bg-white/80 px-3 shadow-[0_3px_0_#5c3f7b]">
                    <svg
                      width="48"
                      height="16"
                      viewBox="0 0 48 16"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M5 4v7h38V4" />
                    </svg>
                    <span className="sr-only">Space</span>
                  </kbd>
                  TO MOVE!
                </span>
              </button>
            </div>
          </div>
        )}

        {activeView === 'studio' && (
          <div className="absolute inset-0 z-40 overflow-y-auto px-4 pb-24 pt-16 sm:px-8 sm:pt-10">
            <div className="mx-auto grid min-h-full max-w-5xl items-center gap-6 lg:grid-cols-[1.05fr_.95fr]">
              <div className="relative min-h-[300px] overflow-hidden rounded-[32px] border-[3px] border-[#5c3f7b] bg-white/35 shadow-[8px_9px_0_#5c3f7b] sm:min-h-[470px]">
                <div className="absolute left-6 top-6 rounded-full border-2 border-[#5c3f7b] bg-[#fff3a0] px-4 py-2 text-[11px] font-black uppercase tracking-[.14em]">
                  {displayName}&apos;s mirror
                </div>
                <div className="absolute right-6 top-6 rounded-full border-2 border-[#5c3f7b] bg-[#ffb5d7] px-3 py-2 text-[10px] font-black uppercase tracking-[.12em]">
                  {genderLabels.find((item) => item.value === look.gender)?.label}
                </div>
                <Unicorn y={52} rotation={-4} isPlaying={false} look={look} x={50} size={42} />
                <span className="sparkle absolute left-[16%] top-[29%] text-3xl text-white">✦</span>
                <span className="sparkle-delayed absolute right-[15%] top-[22%] text-2xl text-[#fff3a0]">
                  ✦
                </span>
                <p className="absolute bottom-5 left-0 right-0 text-center text-xs font-black uppercase tracking-[.18em] text-[#5c3f7b]/70">
                  {genderLabels.find((item) => item.value === look.gender)?.pronoun} look &amp; name
                  save automatically
                </p>
              </div>

              <div className="rounded-[30px] border-[3px] border-[#5c3f7b] bg-[#fff8fd] p-5 shadow-[8px_9px_0_#5c3f7b] sm:p-7">
                <p className="text-xs font-black uppercase tracking-[.18em] text-[#df3e8b]">
                  Magic wardrobe
                </p>
                <h2 className="font-game mt-1 text-4xl uppercase text-[#5c3f7b]">
                  DRESS {displayName}
                </h2>

                <div className="mt-5 grid gap-4 sm:grid-cols-[1.1fr_.9fr]">
                  <label htmlFor="unicorn-name-input" className="block">
                    <span className="mb-2 block text-xs font-black uppercase tracking-[.15em]">
                      Name your unicorn
                    </span>
                    <input
                      id="unicorn-name-input"
                      type="text"
                      maxLength={18}
                      value={look.name}
                      placeholder="Luna"
                      onChange={(event) =>
                        setLook((current) => ({ ...current, name: event.target.value }))
                      }
                      onBlur={() => {
                        if (!look.name.trim()) {
                          setLook((current) => ({ ...current, name: 'Luna' }))
                        }
                      }}
                      className="w-full rounded-xl border-[3px] border-[#5c3f7b] bg-white px-4 py-2.5 text-sm font-bold text-[#4f376b] outline-none focus:shadow-[0_0_0_4px_#ffd3e8]"
                    />
                  </label>

                  <fieldset>
                    <legend className="mb-2 text-xs font-black uppercase tracking-[.15em]">
                      Gender
                    </legend>
                    <div className="flex h-[45px] rounded-xl border-[3px] border-[#5c3f7b] bg-white p-1">
                      {genderLabels.map((item) => (
                        <button
                          key={item.value}
                          onClick={() => setLook((current) => ({ ...current, gender: item.value }))}
                          className={`min-w-0 flex-1 rounded-lg px-1 text-[9px] font-black transition-colors ${
                            look.gender === item.value
                              ? 'bg-[#ff9ecb] text-[#5c3f7b]'
                              : 'text-[#786584] hover:bg-[#f5e9f7]'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </fieldset>
                </div>

                <fieldset className="mt-6">
                  <legend className="mb-3 text-xs font-black uppercase tracking-[.15em]">
                    Outfit
                  </legend>
                  <div className="grid grid-cols-2 gap-2">
                    {outfitLabels.map((item) => (
                      <button
                        key={item.value}
                        onClick={() => setLook((current) => ({ ...current, outfit: item.value }))}
                        className={`rounded-xl border-2 border-[#5c3f7b] px-3 py-3 text-xs font-black transition-transform hover:-translate-y-0.5 ${
                          look.outfit === item.value
                            ? 'bg-[#ff9ecb] shadow-[3px_3px_0_#5c3f7b]'
                            : 'bg-white'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </fieldset>

                <fieldset className="mt-6">
                  <legend className="mb-3 text-xs font-black uppercase tracking-[.15em]">
                    Mane &amp; tail
                  </legend>
                  <div className="flex flex-wrap gap-3">
                    {maneLabels.map((item) => (
                      <button
                        key={item.value}
                        onClick={() =>
                          setLook((current) => ({ ...current, maneColor: item.value }))
                        }
                        aria-label={`${item.label} mane`}
                        className={`h-11 w-11 rounded-full border-[3px] border-[#5c3f7b] transition-transform hover:scale-110 ${
                          look.maneColor === item.value
                            ? 'scale-110 shadow-[0_0_0_3px_white,0_0_0_6px_#5c3f7b]'
                            : ''
                        }`}
                        style={{ backgroundColor: item.color }}
                      />
                    ))}
                  </div>
                </fieldset>

                <fieldset className="mt-6">
                  <legend className="mb-3 text-xs font-black uppercase tracking-[.15em]">
                    Eye color
                  </legend>
                  <div className="flex flex-wrap gap-3">
                    {eyeLabels.map((item) => (
                      <button
                        key={item.value}
                        onClick={() => setLook((current) => ({ ...current, eyeColor: item.value }))}
                        aria-label={`${item.label} eyes`}
                        className={`h-10 w-10 rounded-full border-[3px] border-white outline-2 outline-[#5c3f7b] transition-transform hover:scale-110 ${
                          look.eyeColor === item.value ? 'scale-110 shadow-[0_0_0_3px_#ffd8ec]' : ''
                        }`}
                        style={{ backgroundColor: item.color }}
                      />
                    ))}
                  </div>
                </fieldset>

                <button
                  onClick={() => changeView('game')}
                  className="font-game mt-7 w-full rounded-xl border-[3px] border-[#5c3f7b] bg-[linear-gradient(110deg,#fff18b,#ffadd8)] py-3 text-lg shadow-[4px_4px_0_#5c3f7b] active:translate-x-1 active:translate-y-1 active:shadow-none"
                >
                  WEAR THIS LOOK
                </button>
              </div>
            </div>
          </div>
        )}

        {activeView === 'multiplayer' && (
          <div className="absolute inset-0 z-40 overflow-y-auto px-4 pb-24 pt-16 sm:px-8 sm:pt-10">
            <div className="mx-auto flex min-h-full max-w-4xl items-center justify-center">
              {!board ? (
                <div className="w-full rounded-[30px] border-[3px] border-[#5c3f7b] bg-[#fff8fd]/95 p-6 shadow-[9px_10px_0_#5c3f7b] sm:p-9">
                  <div className="text-center">
                    <p className="text-xs font-black uppercase tracking-[.18em] text-[#df3e8b]">
                      Race for the most stardust
                    </p>
                    <h2 className="font-game mt-2 text-4xl text-[#5c3f7b] sm:text-5xl">
                      PLAY TOGETHER
                    </h2>
                    <p className="mx-auto mt-3 max-w-lg text-sm font-bold text-[#705c7f]">
                      Create a room, share its code, and see everyone&apos;s best run on one live
                      leaderboard.
                    </p>
                  </div>

                  <label className="mx-auto mt-7 block max-w-md">
                    <span className="mb-2 block text-[11px] font-black uppercase tracking-[.15em]">
                      Your player name
                    </span>
                    <input
                      value={playerName}
                      onChange={(event) => setPlayerName(event.target.value)}
                      maxLength={20}
                      placeholder="Sparkle name"
                      className="w-full rounded-xl border-[3px] border-[#5c3f7b] bg-white px-4 py-3 text-sm font-bold outline-none focus:shadow-[0_0_0_4px_#ffd3e8]"
                    />
                  </label>

                  <div className="mt-6 grid gap-4 md:grid-cols-2">
                    <div className="rounded-2xl border-2 border-[#5c3f7b]/25 bg-[#f1e5ff] p-5">
                      <h3 className="font-game text-xl">MAKE A ROOM</h3>
                      <input
                        value={roomName}
                        onChange={(event) => setRoomName(event.target.value)}
                        maxLength={32}
                        placeholder="Room name"
                        className="mt-3 w-full rounded-xl border-2 border-[#5c3f7b] bg-white px-4 py-3 text-sm font-bold outline-none"
                      />
                      <button
                        onClick={handleCreateRoom}
                        disabled={isMultiplayerPending}
                        className="font-game mt-3 w-full rounded-xl border-2 border-[#5c3f7b] bg-[#16c9c8] py-3 text-white shadow-[3px_3px_0_#5c3f7b] disabled:opacity-60"
                      >
                        {isMultiplayerPending ? 'OPENING...' : 'CREATE ROOM'}
                      </button>
                    </div>
                    <div className="rounded-2xl border-2 border-[#5c3f7b]/25 bg-[#ffe0ef] p-5">
                      <h3 className="font-game text-xl">JOIN A FRIEND</h3>
                      <input
                        value={roomCode}
                        onChange={(event) => setRoomCode(event.target.value.toUpperCase())}
                        maxLength={6}
                        placeholder="6-letter code"
                        className="mt-3 w-full rounded-xl border-2 border-[#5c3f7b] bg-white px-4 py-3 text-center text-sm font-black uppercase tracking-[.25em] outline-none"
                      />
                      <button
                        onClick={handleJoinRoom}
                        disabled={isMultiplayerPending}
                        className="font-game mt-3 w-full rounded-xl border-2 border-[#5c3f7b] bg-[#ff5ca7] py-3 text-white shadow-[3px_3px_0_#5c3f7b] disabled:opacity-60"
                      >
                        {isMultiplayerPending ? 'JOINING...' : 'JOIN ROOM'}
                      </button>
                    </div>
                  </div>
                  {multiplayerError && (
                    <p className="mt-5 rounded-xl bg-[#ffe0e7] px-4 py-3 text-center text-sm font-black text-[#9e3159]">
                      {multiplayerError}
                    </p>
                  )}
                </div>
              ) : (
                <div className="grid w-full gap-5 lg:grid-cols-[.8fr_1.2fr]">
                  <div className="rounded-[28px] border-[3px] border-[#5c3f7b] bg-[#fff8fd] p-6 text-center shadow-[7px_8px_0_#5c3f7b]">
                    <p className="text-[10px] font-black uppercase tracking-[.18em] text-[#df3e8b]">
                      Room
                    </p>
                    <h2 className="font-game mt-1 text-3xl">{board.roomName}</h2>
                    <div className="mt-5 rounded-2xl border-2 border-dashed border-[#5c3f7b] bg-[#fff3a0] px-4 py-4">
                      <p className="text-[10px] font-black uppercase tracking-[.15em]">
                        Share this code
                      </p>
                      <p className="font-game mt-1 text-4xl tracking-[.14em]">{board.roomCode}</p>
                    </div>
                    <button
                      onClick={startGame}
                      className="font-game mt-5 w-full rounded-xl border-[3px] border-[#5c3f7b] bg-[linear-gradient(110deg,#fff18b,#ffadd8)] py-3 text-lg shadow-[4px_4px_0_#5c3f7b]"
                    >
                      PLAY THIS ROOM
                    </button>
                    <button
                      onClick={() => {
                        setBoard(null)
                        setMultiplayerError('')
                      }}
                      className="mt-5 text-xs font-black uppercase tracking-wider underline"
                    >
                      Leave room
                    </button>
                  </div>
                  <div className="rounded-[28px] border-[3px] border-[#5c3f7b] bg-[#fff8fd] p-6 shadow-[7px_8px_0_#5c3f7b]">
                    <div className="flex items-end justify-between">
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[.18em] text-[#df3e8b]">
                          Shared leaderboard
                        </p>
                        <h3 className="font-game mt-1 text-3xl">TOP SPARKLERS</h3>
                      </div>
                      <span className="text-[10px] font-black uppercase text-[#766381]">
                        {isMultiplayerPending ? 'Refreshing' : 'Live'}
                      </span>
                    </div>
                    <ol className="mt-5 space-y-2">
                      {board.entries.length ? (
                        board.entries.map((entry, index) => (
                          <li
                            key={entry.id}
                            className="flex items-center justify-between rounded-xl border-2 border-[#5c3f7b]/15 bg-white px-4 py-3"
                          >
                            <div className="flex items-center gap-3">
                              <span className="font-game flex h-8 w-8 items-center justify-center rounded-full bg-[#eadcff] text-sm">
                                {index + 1}
                              </span>
                              <div>
                                <p className="text-sm font-black">{entry.playerName}</p>
                                <p className="text-[9px] font-bold uppercase text-[#87758f]">
                                  {entry.maneColor} · {entry.outfit}
                                </p>
                              </div>
                            </div>
                            <span className="font-game text-2xl text-[#f03e91]">{entry.score}</span>
                          </li>
                        ))
                      ) : (
                        <li className="rounded-2xl border-2 border-dashed border-[#5c3f7b]/30 py-10 text-center text-sm font-bold text-[#816d8b]">
                          No runs yet. Be the first to sparkle.
                        </li>
                      )}
                    </ol>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {activeView === 'game' && gameState === 'gameover' && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#204d57]/25 px-5 pb-[8%] backdrop-blur-[2px]">
            <div className="w-full max-w-[360px] text-center">
              <h2 className="font-game -rotate-2 text-[54px] text-white drop-shadow-[0_5px_0_#173e48] sm:text-[66px]">
                OOPS, GLITTER!
              </h2>
              <div className="mt-4 rounded-[24px] border-[3px] border-[#5c3f7b] bg-[#fff5fc] p-6 shadow-[7px_8px_0_#5c3f7b]">
                <p className="mb-3 inline-block rounded-full border-2 border-[#5c3f7b] bg-[#fff3a0] px-3 py-1 text-[11px] font-black uppercase tracking-[.14em] text-[#5c3f7b]">
                  ✦ {displayName}&apos;s Run ✦
                </p>
                <div className="grid grid-cols-2 divide-x-2 divide-[#173e48]/20">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[.16em] text-[#668086]">
                      Score
                    </p>
                    <p className="font-game mt-1 text-5xl text-[#f36daf]">{score}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[.16em] text-[#668086]">
                      Best
                    </p>
                    <p className="font-game mt-1 text-5xl text-[#8c67ca]">{bestScore}</p>
                  </div>
                </div>
                <button
                  onClick={startGame}
                  className="mystik-retry-button font-game mt-6 w-full rounded-xl border-[3px] border-[#5c3f7b] bg-[linear-gradient(110deg,#fff18b,#ffadd8)] py-3.5 text-xl shadow-[4px_4px_0_#5c3f7b] active:translate-x-1 active:translate-y-1 active:shadow-none"
                >
                  TRY AGAIN
                </button>
                {board && (
                  <button
                    onClick={postScore}
                    disabled={isMultiplayerPending || scorePosted}
                    className="font-game mt-3 w-full rounded-xl border-[3px] border-[#5c3f7b] bg-[#16c9c8] py-3 text-sm text-white shadow-[4px_4px_0_#5c3f7b] disabled:opacity-65"
                  >
                    {scorePosted
                      ? 'SCORE POSTED!'
                      : isMultiplayerPending
                        ? 'POSTING...'
                        : 'POST TO ROOM'}
                  </button>
                )}
              </div>
              <p className="mt-5 text-xs font-black uppercase tracking-wider text-white drop-shadow-[0_2px_0_#315e65]">
                Tap anywhere to restart
              </p>
            </div>
          </div>
        )}
      </section>
    </main>
  )
}

declare global {
  interface Window {
    webkitAudioContext: typeof AudioContext
  }
}

export default App
