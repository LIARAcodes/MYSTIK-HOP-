'use server'

import config from '@payload-config'
import { getPayload } from 'payload'

const outfits = ['none', 'crown', 'cape', 'tutu'] as const
const maneColors = ['rainbow', 'berry', 'ocean', 'sunset'] as const
const eyeColors = ['violet', 'blue', 'green', 'rose'] as const

type Outfit = (typeof outfits)[number]
type ManeColor = (typeof maneColors)[number]
type EyeColor = (typeof eyeColors)[number]

export type MultiplayerEntry = {
  id: string
  playerName: string
  score: number
  outfit: Outfit
  maneColor: ManeColor
  eyeColor: EyeColor
}

export type MultiplayerBoard = {
  roomId: string
  roomName: string
  roomCode: string
  entries: MultiplayerEntry[]
}

export type MultiplayerResult = { ok: true; board: MultiplayerBoard } | { ok: false; error: string }

const cleanText = (value: unknown, maxLength: number) =>
  typeof value === 'string' ? value.trim().replace(/\s+/g, ' ').slice(0, maxLength) : ''

const asRecord = (value: unknown): Record<string, unknown> =>
  typeof value === 'object' && value !== null ? (value as Record<string, unknown>) : {}

const isChoice = <T extends readonly string[]>(value: unknown, choices: T): value is T[number] =>
  typeof value === 'string' && choices.includes(value)

async function boardForRoom(roomId: string): Promise<MultiplayerBoard | null> {
  const payload = await getPayload({ config })
  try {
    const room = await payload.findByID({
      collection: 'multiplayer-rooms',
      id: roomId,
      overrideAccess: false,
      depth: 0,
    })
    const scores = await payload.find({
      collection: 'multiplayer-scores',
      overrideAccess: false,
      depth: 0,
      limit: 12,
      sort: '-score',
      where: { room: { equals: room.id } },
    })
    return {
      roomId: String(room.id),
      roomName: room.name,
      roomCode: room.code ?? '',
      entries: scores.docs.map((entry) => ({
        id: String(entry.id),
        playerName: entry.playerName,
        score: entry.score,
        outfit: entry.outfit,
        maneColor: entry.maneColor,
        eyeColor: entry.eyeColor,
      })),
    }
  } catch {
    return null
  }
}

export async function createRoom(input: unknown): Promise<MultiplayerResult> {
  const values = asRecord(input)
  const roomName = cleanText(values.roomName, 32)
  const playerName = cleanText(values.playerName, 20)
  if (roomName.length < 2 || playerName.length < 2) {
    return { ok: false, error: 'Add a room name and a player name.' }
  }

  try {
    const payload = await getPayload({ config })
    const room = await payload.create({
      collection: 'multiplayer-rooms',
      overrideAccess: false,
      draft: false,
      data: { name: roomName, createdBy: playerName },
    })
    const board = await boardForRoom(String(room.id))
    return board ? { ok: true, board } : { ok: false, error: 'The room could not be opened.' }
  } catch {
    return { ok: false, error: 'Could not create a room. Please try again.' }
  }
}

export async function joinRoom(input: unknown): Promise<MultiplayerResult> {
  const values = asRecord(input)
  const code = cleanText(values.code, 6).toUpperCase()
  if (code.length !== 6) return { ok: false, error: 'Room codes have 6 characters.' }

  try {
    const payload = await getPayload({ config })
    const rooms = await payload.find({
      collection: 'multiplayer-rooms',
      overrideAccess: false,
      depth: 0,
      limit: 1,
      where: {
        and: [{ code: { equals: code } }, { status: { equals: 'open' } }],
      },
    })
    const room = rooms.docs[0]
    if (!room) return { ok: false, error: 'No open room has that code.' }
    const board = await boardForRoom(String(room.id))
    return board ? { ok: true, board } : { ok: false, error: 'The room is unavailable.' }
  } catch {
    return { ok: false, error: 'Could not join this room. Please try again.' }
  }
}

export async function refreshBoard(roomId: unknown): Promise<MultiplayerResult> {
  const id = cleanText(roomId, 80)
  if (!id) return { ok: false, error: 'Join a room first.' }
  const board = await boardForRoom(id)
  return board ? { ok: true, board } : { ok: false, error: 'The room is unavailable.' }
}

export async function submitMultiplayerScore(input: unknown): Promise<MultiplayerResult> {
  const values = asRecord(input)
  const roomId = cleanText(values.roomId, 80)
  const playerName = cleanText(values.playerName, 20)
  const score = Number.isFinite(values.score)
    ? Math.max(0, Math.min(9999, Math.floor(values.score as number)))
    : -1
  const outfit = values.outfit
  const maneColor = values.maneColor
  const eyeColor = values.eyeColor
  if (
    !roomId ||
    playerName.length < 2 ||
    score < 0 ||
    !isChoice(outfit, outfits) ||
    !isChoice(maneColor, maneColors) ||
    !isChoice(eyeColor, eyeColors)
  ) {
    return { ok: false, error: 'Your run details are not valid.' }
  }

  try {
    const payload = await getPayload({ config })
    await payload.create({
      collection: 'multiplayer-scores',
      overrideAccess: false,
      draft: false,
      data: {
        room: roomId,
        playerName,
        score,
        outfit,
        maneColor,
        eyeColor,
      },
    })
    const board = await boardForRoom(roomId)
    return board
      ? { ok: true, board }
      : { ok: false, error: 'Score saved, but the board did not load.' }
  } catch {
    return { ok: false, error: 'Could not save this run. Please try again.' }
  }
}
