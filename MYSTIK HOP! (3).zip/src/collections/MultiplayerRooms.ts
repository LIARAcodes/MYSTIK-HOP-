import type { CollectionConfig } from 'payload'

const isPayloadAdmin = ({ req }: { req: { user?: { collection?: string } | null } }) =>
  req.user?.collection === 'admins'

const makeRoomCode = () => {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  return Array.from(
    { length: 6 },
    () => alphabet[Math.floor(Math.random() * alphabet.length)],
  ).join('')
}

export const MultiplayerRooms: CollectionConfig = {
  slug: 'multiplayer-rooms',
  admin: {
    group: 'Multiplayer',
    useAsTitle: 'name',
    defaultColumns: ['name', 'code', 'createdBy', 'createdAt'],
  },
  access: {
    create: () => true,
    read: () => true,
    update: isPayloadAdmin,
    delete: isPayloadAdmin,
  },
  fields: [
    {
      name: 'name',
      type: 'text',
      required: true,
      minLength: 2,
      maxLength: 32,
    },
    {
      name: 'code',
      type: 'text',
      unique: true,
      index: true,
      defaultValue: makeRoomCode,
      access: {
        create: () => false,
        update: () => false,
      },
      admin: {
        position: 'sidebar',
        readOnly: true,
      },
    },
    {
      name: 'createdBy',
      type: 'text',
      required: true,
      minLength: 2,
      maxLength: 20,
    },
    {
      name: 'status',
      type: 'select',
      defaultValue: 'open',
      options: [
        { label: 'Open', value: 'open' },
        { label: 'Closed', value: 'closed' },
      ],
      access: {
        create: () => false,
        update: isPayloadAdmin,
      },
      admin: {
        position: 'sidebar',
      },
    },
  ],
}
