import type { CollectionConfig, PayloadRequest } from 'payload'

const isPayloadAdmin = ({ req }: { req: { user?: { collection?: string } | null } }) =>
  req.user?.collection === 'admins'

export const MultiplayerScores: CollectionConfig = {
  slug: 'multiplayer-scores',
  admin: {
    group: 'Multiplayer',
    useAsTitle: 'playerName',
    defaultColumns: ['playerName', 'score', 'room', 'createdAt'],
  },
  access: {
    create: () => true,
    read: () => true,
    update: () => false,
    delete: isPayloadAdmin,
  },
  fields: [
    {
      name: 'room',
      type: 'relationship',
      relationTo: 'multiplayer-rooms',
      required: true,
      index: true,
      validate: async (value: unknown, { req }: { req: PayloadRequest }) => {
        const roomID =
          typeof value === 'object' && value && 'id' in value
            ? (value as { id: string | number }).id
            : typeof value === 'string' || typeof value === 'number'
              ? value
              : null
        if (!roomID) return 'Choose a multiplayer room.'
        try {
          const room = await req.payload.findByID({
            collection: 'multiplayer-rooms',
            id: roomID,
            overrideAccess: false,
            user: req.user,
            depth: 0,
          })
          return room.status !== 'closed' || 'This room is closed.'
        } catch {
          return 'This multiplayer room is unavailable.'
        }
      },
    },
    {
      name: 'playerName',
      type: 'text',
      required: true,
      minLength: 2,
      maxLength: 20,
    },
    {
      name: 'score',
      type: 'number',
      required: true,
      min: 0,
      max: 9999,
      index: true,
    },
    {
      name: 'outfit',
      type: 'select',
      required: true,
      options: ['none', 'crown', 'cape', 'tutu'],
    },
    {
      name: 'maneColor',
      type: 'select',
      required: true,
      options: ['rainbow', 'berry', 'ocean', 'sunset'],
    },
    {
      name: 'eyeColor',
      type: 'select',
      required: true,
      options: ['violet', 'blue', 'green', 'rose'],
    },
  ],
}
